package com.teste.primeiro_exemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroExemploApplicationTests {

	@Test
	void contextLoads() {
	}

}
